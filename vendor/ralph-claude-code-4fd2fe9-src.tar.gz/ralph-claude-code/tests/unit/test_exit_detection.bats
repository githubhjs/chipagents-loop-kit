#!/usr/bin/env bats
# Unit Tests for Exit Detection Logic

load '../helpers/test_helper'

setup() {
    # Source helper functions
    source "$(dirname "$BATS_TEST_FILENAME")/../helpers/test_helper.bash"

    # Load the production functions without running the loop or its startup code.
    source "${BATS_TEST_DIRNAME}/../../lib/int_utils.sh"
    local function_name function_body
    for function_name in _safe_count _count_blocking_unchecked should_exit_gracefully; do
        function_body=$(sed -n "/^${function_name}() {/,/^}/p" "${BATS_TEST_DIRNAME}/../../ralph_loop.sh")
        [[ -n "$function_body" ]] || return 1
        eval "$function_body"
        declare -F "$function_name" > /dev/null || return 1
    done
    log_status() { :; }

    # Set up environment with .ralph/ subfolder structure
    export RALPH_DIR=".ralph"
    export EXIT_SIGNALS_FILE="$RALPH_DIR/.exit_signals"
    export RESPONSE_ANALYSIS_FILE="$RALPH_DIR/.response_analysis"
    export MAX_CONSECUTIVE_TEST_LOOPS=3
    export MAX_CONSECUTIVE_DONE_SIGNALS=2
    # Issue #239: default optional sections (matches ralph_loop.sh default); tests may override
    export OPTIONAL_SECTIONS="Optional,Future,Future Enhancements,Nice to Have"

    # Create temp test directory
    export TEST_TEMP_DIR="$(mktemp -d)"
    cd "$TEST_TEMP_DIR"
    mkdir -p "$RALPH_DIR"

    # Initialize exit signals file
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"
}

teardown() {
    cd /
    rm -rf "$TEST_TEMP_DIR"
}

# Test 1: No exit when signals are empty
@test "should_exit_gracefully returns empty with no signals" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 2: Exit on test saturation (3 test loops)
@test "should_exit_gracefully exits on test saturation (3 loops)" {
    echo '{"test_only_loops": [1,2,3], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully)
    assert_equal "$result" "test_saturation"
}

# Test 4: No exit with only 2 test loops
@test "should_exit_gracefully continues with 2 test loops" {
    echo '{"test_only_loops": [1,2], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 5: Exit on done signals (2 signals)
@test "should_exit_gracefully exits on 2 done signals" {
    echo '{"test_only_loops": [], "done_signals": [1,2], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" "completion_signals"
}

# Test 7: No exit with only 1 done signal
@test "should_exit_gracefully continues with 1 done signal" {
    echo '{"test_only_loops": [], "done_signals": [1], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 8: Exit on completion indicators (2 indicators) with EXIT_SIGNAL=true
@test "should_exit_gracefully exits on 2 completion indicators" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    # Must also have exit_signal=true in .response_analysis (after fix)
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 2,
    "analysis": {
        "exit_signal": true,
        "confidence_score": 80
    }
}
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" "project_complete"
}

# Test 9: No exit with only 1 completion indicator
@test "should_exit_gracefully continues with 1 completion indicator" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1]}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 10: Exit when fix_plan.md all items complete
@test "should_exit_gracefully exits when all fix_plan items complete" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [x] Task 1
- [x] Task 2
- [x] Task 3
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# Test 11: No exit when fix_plan.md partially complete
@test "should_exit_gracefully continues when fix_plan partially complete" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [x] Task 1
- [ ] Task 2
- [ ] Task 3
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# --- Issue #239: Optional/Future section support in fix_plan.md ---

# Unchecked items under an Optional section do not block exit when required work is done
@test "issue #239: exits when only Optional-section items remain unchecked" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## High Priority
- [x] Core feature implementation

## Optional
- [ ] Frontend integration
- [ ] SMS verification
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# Unchecked items under a Future section also do not block exit
@test "issue #239: exits when only Future-section items remain unchecked" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Medium Priority
- [x] Additional features

## Future Enhancements
- [ ] Multi-language support
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# Unchecked items in a NON-optional section still block exit (backward compatible)
@test "issue #239: still blocks when a required section has unchecked items" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## High Priority
- [x] Core feature

## Low Priority
- [ ] Configurable settings

## Optional
- [ ] Frontend integration
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Section matching is case-insensitive
@test "issue #239: optional section match is case-insensitive" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Done
- [x] Real work

## OPTIONAL
- [ ] Skippable extra
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# Optional context persists into deeper subsections...
@test "issue #239: subsections under an optional section stay optional" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Core
- [x] Implemented

## Optional
### Nice extras
- [ ] Themeing
- [ ] Animations
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# ...and a same-or-higher-level heading after an optional section ends optional context
@test "issue #239: a following required section re-blocks after an optional one" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Core
- [x] Implemented

## Optional
- [ ] Skippable

## Cleanup
- [ ] Required teardown
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# OPTIONAL_SECTIONS is configurable; default names are NOT optional when overridden
@test "issue #239: OPTIONAL_SECTIONS is configurable" {
    export OPTIONAL_SECTIONS="Backlog"
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Core
- [x] Implemented

## Backlog
- [ ] Someday item
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "plan_complete"
}

# With OPTIONAL_SECTIONS overridden, the default "Optional" header is no longer optional
@test "issue #239: overriding OPTIONAL_SECTIONS drops the built-in defaults" {
    export OPTIONAL_SECTIONS="Backlog"
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Core
- [x] Implemented

## Optional
- [ ] Now required because defaults were overridden
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Backward compatibility: a plan with no optional sections behaves exactly as before
@test "issue #239: no optional sections present preserves prior behavior" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [x] Task 1
- [ ] Task 2
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 12: No exit when fix_plan.md missing
@test "should_exit_gracefully continues when fix_plan missing" {
    # Don't create fix_plan.md

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 13: No exit when exit signals file missing
@test "should_exit_gracefully continues when exit signals file missing" {
    rm -f "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 14: Handle corrupted JSON gracefully
@test "should_exit_gracefully handles corrupted JSON" {
    echo 'invalid json{' > "$EXIT_SIGNALS_FILE"

    # Should not crash, should treat as 0 signals
    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 15: Multiple exit conditions simultaneously (test takes priority)
@test "should_exit_gracefully returns first matching condition" {
    echo '{"test_only_loops": [1,2,3,4], "done_signals": [1,2], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    result=$(should_exit_gracefully)
    # Should return test_saturation (checked first)
    assert_equal "$result" "test_saturation"
}

# Test 16: fix_plan.md with no checkboxes
@test "should_exit_gracefully handles fix_plan with no checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
This is just text, no tasks yet.
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 17: fix_plan.md with mixed checkbox formats
@test "should_exit_gracefully handles mixed checkbox formats" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [x] Task 1 completed
- [ ] Task 2 pending
- [X] Task 3 completed (uppercase)
- [] Task 4 (invalid format, should not count)
EOF

    result=$(should_exit_gracefully || true)
    # 2 completed out of 3 valid tasks
    assert_equal "$result" ""
}

# =============================================================================
# EXIT_SIGNAL RESPECT TESTS (Issue: Premature exit when EXIT_SIGNAL=false)
# =============================================================================
# These tests verify that completion indicators only trigger exit when
# Claude's explicit EXIT_SIGNAL is true, preventing premature exits during
# productive iterations.

# Test 21: Completion indicators with EXIT_SIGNAL=false should continue
@test "should_exit_gracefully continues when completion indicators high but EXIT_SIGNAL=false" {
    # Setup: High completion indicators (would normally exit)
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2,3]}' > "$EXIT_SIGNALS_FILE"

    # Setup: Claude's explicit exit signal is false (still working)
    mkdir -p "$(dirname "$RESPONSE_ANALYSIS_FILE")"
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 3,
    "timestamp": "2026-01-12T10:00:00Z",
    "output_format": "text",
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": true,
        "files_modified": 5,
        "confidence_score": 70,
        "exit_signal": false,
        "work_summary": "Implementing feature, still in progress"
    }
}
EOF

    result=$(should_exit_gracefully || true)
    # Should NOT exit because EXIT_SIGNAL is false
    assert_equal "$result" ""
}

# Test 22: Completion indicators with EXIT_SIGNAL=true should exit
@test "should_exit_gracefully exits when completion indicators high AND EXIT_SIGNAL=true" {
    # Setup: High completion indicators
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    # Setup: Claude's explicit exit signal is true (project complete)
    mkdir -p "$(dirname "$RESPONSE_ANALYSIS_FILE")"
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 2,
    "timestamp": "2026-01-12T10:00:00Z",
    "output_format": "text",
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": false,
        "files_modified": 0,
        "confidence_score": 100,
        "exit_signal": true,
        "work_summary": "All tasks complete, project ready for review"
    }
}
EOF

    result=$(should_exit_gracefully)
    # Should exit because BOTH conditions are met
    assert_equal "$result" "project_complete"
}

# Test 23: Completion indicators without .response_analysis file should continue
@test "should_exit_gracefully continues when .response_analysis file missing" {
    # Setup: High completion indicators
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2,3]}' > "$EXIT_SIGNALS_FILE"

    # Don't create .response_analysis - defaults to exit_signal=false
    rm -f "$RESPONSE_ANALYSIS_FILE"

    result=$(should_exit_gracefully || true)
    # Should NOT exit because exit_signal defaults to false
    assert_equal "$result" ""
}

# Test 24: Completion indicators with malformed .response_analysis should continue
@test "should_exit_gracefully continues when .response_analysis has invalid JSON" {
    # Setup: High completion indicators
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    # Setup: Corrupted/invalid JSON in .response_analysis
    echo 'invalid json{broken' > "$RESPONSE_ANALYSIS_FILE"

    result=$(should_exit_gracefully || true)
    # Should NOT exit because jq parsing fails, defaults to false
    assert_equal "$result" ""
}

# Test 25: EXIT_SIGNAL=true but completion indicators below threshold should continue
@test "should_exit_gracefully continues when EXIT_SIGNAL=true but indicators below threshold" {
    # Setup: Only 1 completion indicator (below threshold of 2)
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1]}' > "$EXIT_SIGNALS_FILE"

    # Setup: Claude says exit is true
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "analysis": {
        "exit_signal": true,
        "confidence_score": 100
    }
}
EOF

    result=$(should_exit_gracefully || true)
    # Should NOT exit because indicators below threshold
    assert_equal "$result" ""
}

# Test 26: EXIT_SIGNAL=false with explicit false value in JSON
@test "should_exit_gracefully handles explicit false exit_signal" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2,3,4]}' > "$EXIT_SIGNALS_FILE"

    # Keep below the independent five-indicator safety circuit breaker.
    # Explicit false value
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "analysis": {
        "exit_signal": false
    }
}
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

@test "should_exit_gracefully safety breaker fires at five indicators despite explicit false" {
    # The breaker is independent of EXIT_SIGNAL: one indicator past test 26's fixture forces the exit
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2,3,4,5]}' > "$EXIT_SIGNALS_FILE"
    echo '{"analysis": {"exit_signal": false}}' > "$RESPONSE_ANALYSIS_FILE"

    result=$(should_exit_gracefully)
    assert_equal "$result" "safety_circuit_breaker"
}

# Test 27: EXIT_SIGNAL missing from analysis object should default to false
@test "should_exit_gracefully defaults to false when exit_signal field missing" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    # analysis object exists but no exit_signal field
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 5,
    "analysis": {
        "confidence_score": 80,
        "has_completion_signal": true,
        "is_test_only": false
    }
}
EOF

    result=$(should_exit_gracefully || true)
    # Missing exit_signal should default to false, so continue
    assert_equal "$result" ""
}

# Test 28: Test priority - test_saturation still takes priority over completion indicators
@test "should_exit_gracefully test_saturation takes priority even with EXIT_SIGNAL=false" {
    # Test loops should still trigger exit regardless of EXIT_SIGNAL
    echo '{"test_only_loops": [1,2,3,4], "done_signals": [], "completion_indicators": [1]}' > "$EXIT_SIGNALS_FILE"

    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "analysis": {
        "exit_signal": false
    }
}
EOF

    result=$(should_exit_gracefully)
    # test_saturation is checked before completion_indicators
    assert_equal "$result" "test_saturation"
}

# Test 29: done_signals still takes priority over completion indicators
@test "should_exit_gracefully done_signals takes priority even with EXIT_SIGNAL=false" {
    echo '{"test_only_loops": [], "done_signals": [1,2,3], "completion_indicators": [1]}' > "$EXIT_SIGNALS_FILE"

    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "analysis": {
        "exit_signal": false
    }
}
EOF

    result=$(should_exit_gracefully)
    # done_signals is checked before completion_indicators
    assert_equal "$result" "completion_signals"
}

# Test 30: Empty analysis object in .response_analysis should default to false
@test "should_exit_gracefully handles empty analysis object" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"

    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 3,
    "analysis": {}
}
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 31: STATUS=COMPLETE but EXIT_SIGNAL=false conflict - EXIT_SIGNAL takes precedence
@test "should_exit_gracefully respects EXIT_SIGNAL=false even when STATUS=COMPLETE" {
    # Setup: High completion indicators
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2,3]}' > "$EXIT_SIGNALS_FILE"

    # Setup: Conflicting signals - STATUS says COMPLETE but EXIT_SIGNAL explicitly false
    # This can happen when Claude marks a phase complete but has more work to do
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 3,
    "timestamp": "2026-01-12T10:00:00Z",
    "output_format": "text",
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": true,
        "files_modified": 3,
        "confidence_score": 100,
        "exit_signal": false,
        "work_summary": "Phase complete, but more phases remain"
    }
}
EOF

    result=$(should_exit_gracefully || true)
    # EXIT_SIGNAL=false should take precedence, continue working
    assert_equal "$result" ""
}

# =============================================================================
# UPDATE_EXIT_SIGNALS TESTS (Issue: Confidence-based completion indicators)
# =============================================================================
# These tests verify that update_exit_signals() only adds to completion_indicators
# when EXIT_SIGNAL is true, not based on confidence score alone.
# This is critical for JSON mode where confidence is always >= 70.

# Source the response_analyzer library for direct testing
# Note: These tests source the library to test update_exit_signals() directly

# Test 32: update_exit_signals should NOT add to completion_indicators when exit_signal=false
@test "update_exit_signals does NOT add to completion_indicators when exit_signal=false" {
    # Source the response analyzer library
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"

    # Initialize exit signals file
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create analysis file with HIGH confidence (70) but exit_signal=false
    # This simulates JSON mode where confidence is always >= 70
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "timestamp": "2026-01-12T10:00:00Z",
    "output_format": "json",
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": true,
        "files_modified": 5,
        "confidence_score": 70,
        "exit_signal": false,
        "work_summary": "Implementing feature, still in progress"
    }
}
EOF

    # Call update_exit_signals
    update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"

    # Verify completion_indicators was NOT incremented
    local indicator_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    assert_equal "$indicator_count" "0"
}

# Test 33: update_exit_signals SHOULD add to completion_indicators when exit_signal=true
@test "update_exit_signals adds to completion_indicators when exit_signal=true" {
    # Source the response analyzer library
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"

    # Initialize exit signals file
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create analysis file with exit_signal=true
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "timestamp": "2026-01-12T10:00:00Z",
    "output_format": "json",
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": false,
        "files_modified": 0,
        "confidence_score": 100,
        "exit_signal": true,
        "work_summary": "All tasks complete"
    }
}
EOF

    # Call update_exit_signals
    update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"

    # Verify completion_indicators WAS incremented
    local indicator_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    assert_equal "$indicator_count" "1"

    # Verify the loop number was recorded
    local loop_recorded=$(jq '.completion_indicators[0]' "$EXIT_SIGNALS_FILE")
    assert_equal "$loop_recorded" "1"
}

# Test 34: update_exit_signals accumulates completion_indicators only on exit_signal=true
@test "update_exit_signals accumulates completion_indicators only when exit_signal=true" {
    # Source the response analyzer library
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"

    # Initialize exit signals file
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Loop 1: exit_signal=false (should NOT add)
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "has_progress": true,
        "confidence_score": 80,
        "exit_signal": false
    }
}
EOF
    update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"

    # Loop 2: exit_signal=false (should NOT add)
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 2,
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "has_progress": true,
        "confidence_score": 90,
        "exit_signal": false
    }
}
EOF
    update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"

    # Loop 3: exit_signal=true (SHOULD add)
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 3,
    "analysis": {
        "has_completion_signal": true,
        "is_test_only": false,
        "has_progress": false,
        "confidence_score": 100,
        "exit_signal": true
    }
}
EOF
    update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"

    # Verify only 1 completion indicator (from loop 3)
    local indicator_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    assert_equal "$indicator_count" "1"

    local loop_recorded=$(jq '.completion_indicators[0]' "$EXIT_SIGNALS_FILE")
    assert_equal "$loop_recorded" "3"
}

# Test 35: JSON mode simulation - 5 loops with exit_signal=false should NOT trigger safety breaker
@test "update_exit_signals JSON mode - 5 loops with exit_signal=false does not fill completion_indicators" {
    # Source the response analyzer library
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"

    # Initialize exit signals file
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Simulate 5 JSON mode loops with high confidence but exit_signal=false
    # This is the exact scenario that caused the bug
    for i in 1 2 3 4 5; do
        cat > "$RESPONSE_ANALYSIS_FILE" << EOF
{
    "loop_number": $i,
    "output_format": "json",
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "has_progress": true,
        "files_modified": 3,
        "confidence_score": 70,
        "exit_signal": false,
        "work_summary": "Working on feature $i"
    }
}
EOF
        update_exit_signals "$RESPONSE_ANALYSIS_FILE" "$EXIT_SIGNALS_FILE"
    done

    # Verify completion_indicators is EMPTY (not filled with 5 indicators)
    local indicator_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    assert_equal "$indicator_count" "0"
}

# =============================================================================
# PERMISSION DENIAL EXIT TESTS (Issue #101)
# =============================================================================
# When Claude Code is denied permission to run commands, Ralph should detect
# this from the permission_denials field and halt the loop to allow user intervention.

# Test 36: Exit on permission denial detected
@test "should_exit_gracefully exits on permission_denied" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create response analysis with permission denials
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "output_format": "json",
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": false,
        "files_modified": 0,
        "confidence_score": 70,
        "exit_signal": false,
        "work_summary": "Tried to run npm install but permission denied",
        "has_permission_denials": true,
        "permission_denial_count": 1,
        "denied_commands": ["npm install"]
    }
}
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "permission_denied"
}

# Test 37: No exit when no permission denials
@test "should_exit_gracefully continues when no permission denials" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create response analysis without permission denials
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "output_format": "json",
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "is_stuck": false,
        "has_progress": true,
        "files_modified": 3,
        "confidence_score": 70,
        "exit_signal": false,
        "work_summary": "Implementing feature",
        "has_permission_denials": false,
        "permission_denial_count": 0,
        "denied_commands": []
    }
}
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# Test 38: Permission denial takes priority over other signals
@test "permission_denied takes priority over test_saturation" {
    # Set up test saturation condition
    echo '{"test_only_loops": [1,2,3], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create response analysis with permission denials
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 3,
    "analysis": {
        "is_test_only": true,
        "has_permission_denials": true,
        "permission_denial_count": 1,
        "denied_commands": ["npm install"]
    }
}
EOF

    # Permission denied should take priority
    result=$(should_exit_gracefully)
    assert_equal "$result" "permission_denied"
}

# Test 39: Multiple permission denials detected
@test "should_exit_gracefully detects multiple permission denials" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "analysis": {
        "has_permission_denials": true,
        "permission_denial_count": 3,
        "denied_commands": ["npm install", "pnpm install", "yarn add lodash"]
    }
}
EOF

    result=$(should_exit_gracefully)
    assert_equal "$result" "permission_denied"
}

# Test 40: Missing has_permission_denials field defaults to false (backward compat)
@test "should_exit_gracefully handles missing permission denial fields" {
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Old format response analysis without permission denial fields
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{
    "loop_number": 1,
    "analysis": {
        "has_completion_signal": false,
        "is_test_only": false,
        "exit_signal": false
    }
}
EOF

    result=$(should_exit_gracefully || true)
    assert_equal "$result" ""
}

# =============================================================================
# CHECKBOX REGEX FIX TESTS (Issue #144)
# =============================================================================
# These tests verify that date entries like [2026-01-29] are NOT counted as
# checkboxes, preventing false "plan_complete" exits when fix_plan.md contains
# dated entries that match the old [*] pattern.

# Test 41: Date entries should NOT be counted as checkboxes
@test "fix_plan.md date entries are not counted as checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Changelog
- [2026-01-29] Initial version
- [2026-01-30] Added feature X
- [2026-01-31] Bug fixes

## Tasks
- [ ] Task 1 pending
- [ ] Task 2 pending
EOF

    result=$(should_exit_gracefully || true)
    # Should NOT exit - there are 2 uncompleted tasks
    assert_equal "$result" ""
}

# Test 42: Date entries mixed with completed tasks should not cause false exit
@test "fix_plan.md with dates and completed tasks counts correctly" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Changelog
- [2026-01-29] Initial version

## Tasks
- [x] Task 1 complete
- [ ] Task 2 pending
EOF

    result=$(should_exit_gracefully || true)
    # 1 completed, 1 pending - should NOT exit
    assert_equal "$result" ""
}

# Test 43: Non-checkbox bracket patterns (NOTE, TODO, FIXME) should be excluded
@test "fix_plan.md bracket patterns like [NOTE] are not checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Notes
- [NOTE] Remember to update docs
- [TODO] Consider refactoring later
- [FIXME] Known issue with edge case
- [WIP] Work in progress

## Tasks
- [ ] Task 1 pending
EOF

    result=$(should_exit_gracefully || true)
    # Only 1 real task (pending) - should NOT exit
    assert_equal "$result" ""
}

# Test 44: Case-insensitive completed checkboxes ([x] and [X])
@test "fix_plan.md counts both [x] and [X] as completed" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [x] Task 1 with lowercase x
- [X] Task 2 with uppercase X
- [x] Task 3 with lowercase x
EOF

    result=$(should_exit_gracefully)
    # All 3 tasks completed - should exit with plan_complete
    assert_equal "$result" "plan_complete"
}

# Test 45: Indented date entries should not be counted
@test "fix_plan.md indented date entries are not checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Releases
  - [2026-01-29] v1.0.0 released
    - [2026-01-30] v1.0.1 patch

## Tasks
- [x] All done
EOF

    result=$(should_exit_gracefully)
    # Only 1 real task (completed) - should exit
    assert_equal "$result" "plan_complete"
}

# Test 46: Empty checkbox [ ] with spaces should be counted as uncompleted
@test "fix_plan.md empty checkboxes with extra spaces" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan
- [ ] Task with single space (valid)
- [  ] Task with double space (invalid format, not counted)
- [x] Completed task
EOF

    result=$(should_exit_gracefully || true)
    # 1 uncompleted, 1 completed - should NOT exit
    assert_equal "$result" ""
}

# Test 47: Version numbers in brackets should not be counted
@test "fix_plan.md version numbers like [v1.0] are not checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Version History
- [v1.0] Initial release
- [v1.1] Added features
- [v2.0] Major update

## Tasks
- [x] Task complete
EOF

    result=$(should_exit_gracefully)
    # Only 1 real task (completed) - should exit
    assert_equal "$result" "plan_complete"
}

# Test 48: Issue/PR references should not be counted
@test "fix_plan.md issue references like [#123] are not checkboxes" {
    cat > "$RALPH_DIR/fix_plan.md" << 'EOF'
# Fix Plan

## Related Issues
- [#141] Progress detection bug
- [#144] Checkbox regex false positives
- [PR#155] Setup improvements

## Tasks
- [ ] Fix issue #141
- [ ] Fix issue #144
EOF

    result=$(should_exit_gracefully || true)
    # 2 uncompleted tasks - should NOT exit
    assert_equal "$result" ""
}

# =============================================================================
# GIT COMMIT DETECTION TESTS (Issue #141)
# =============================================================================
# These tests verify that when Claude commits within a loop, the committed files
# are counted as progress even though there are no uncommitted changes.

# Helper function to detect progress including git commits
detect_progress_with_commits() {
    local loop_start_sha="$1"
    local current_sha="$2"
    local files_changed=0

    # Check for committed changes since loop start
    if [[ -n "$loop_start_sha" && -n "$current_sha" && "$loop_start_sha" != "$current_sha" ]]; then
        # Files changed in commits between loop start and current HEAD
        files_changed=$(git diff --name-only "$loop_start_sha" "$current_sha" 2>/dev/null | wc -l || echo 0)
        files_changed=$(echo "$files_changed" | tr -d ' ')
    else
        # Fall back to uncommitted changes
        files_changed=$(git diff --name-only 2>/dev/null | wc -l || echo 0)
        files_changed=$(echo "$files_changed" | tr -d ' ')
    fi

    echo "$files_changed"
}

# Test 49: Git commit detection - files changed in commit count as progress
@test "git commit detection counts committed files as progress" {
    # Skip if git is not available
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Initialize a git repo
    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"

    # Create initial commit
    echo "initial" > file1.txt
    git add file1.txt
    git commit --quiet -m "Initial commit"

    local loop_start_sha=$(git rev-parse HEAD)

    # Simulate Claude making changes and committing within the loop
    echo "modified" > file1.txt
    echo "new file" > file2.txt
    git add file1.txt file2.txt
    git commit --quiet -m "Claude's work"

    local current_sha=$(git rev-parse HEAD)

    # Detect progress
    local files_changed=$(detect_progress_with_commits "$loop_start_sha" "$current_sha")

    # Should detect 2 files changed
    [ "$files_changed" -eq 2 ]
}

# Test 50: Git commit detection - no progress when SHA unchanged
@test "git commit detection returns 0 when no commits made" {
    # Skip if git is not available
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Initialize a git repo
    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"

    # Create initial commit
    echo "initial" > file1.txt
    git add file1.txt
    git commit --quiet -m "Initial commit"

    local loop_start_sha=$(git rev-parse HEAD)
    local current_sha=$(git rev-parse HEAD)

    # No uncommitted changes either
    local files_changed=$(detect_progress_with_commits "$loop_start_sha" "$current_sha")

    # Should detect 0 files (no commits, no uncommitted changes)
    [ "$files_changed" -eq 0 ]
}

# Test 51: Git commit detection - falls back to uncommitted when no commit
@test "git commit detection falls back to uncommitted changes" {
    # Skip if git is not available
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Initialize a git repo
    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"

    # Create initial commit with two tracked files
    echo "initial1" > file1.txt
    echo "initial2" > file2.txt
    git add file1.txt file2.txt
    git commit --quiet -m "Initial commit"

    local loop_start_sha=$(git rev-parse HEAD)

    # Make uncommitted changes to tracked files (no commit)
    echo "modified1" > file1.txt
    echo "modified2" > file2.txt

    local current_sha=$(git rev-parse HEAD)  # Same as loop_start_sha

    # Detect progress - should fall back to uncommitted changes
    # Note: git diff only shows modified tracked files, not untracked files
    local files_changed=$(detect_progress_with_commits "$loop_start_sha" "$current_sha")

    # Should detect 2 uncommitted modified files
    [ "$files_changed" -eq 2 ]
}

# Test 52: Git commit detection - multiple commits within loop
@test "git commit detection counts files across multiple commits" {
    # Skip if git is not available
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Initialize a git repo
    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"

    # Create initial commit
    echo "initial" > file1.txt
    git add file1.txt
    git commit --quiet -m "Initial commit"

    local loop_start_sha=$(git rev-parse HEAD)

    # First commit within loop
    echo "change1" > file1.txt
    git add file1.txt
    git commit --quiet -m "First change"

    # Second commit within loop
    echo "new" > file2.txt
    git add file2.txt
    git commit --quiet -m "Second change"

    # Third commit within loop
    echo "another" > file3.txt
    git add file3.txt
    git commit --quiet -m "Third change"

    local current_sha=$(git rev-parse HEAD)

    # Detect progress
    local files_changed=$(detect_progress_with_commits "$loop_start_sha" "$current_sha")

    # Should detect 3 files (one per commit)
    [ "$files_changed" -eq 3 ]
}

# Test 53: Git commit detection handles empty loop_start_sha
@test "git commit detection handles missing loop_start_sha" {
    # Skip if git is not available
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Initialize a git repo
    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"

    # Create initial commit
    echo "initial" > file1.txt
    git add file1.txt
    git commit --quiet -m "Initial commit"

    # Make uncommitted changes
    echo "modified" > file1.txt

    local current_sha=$(git rev-parse HEAD)

    # Detect progress with empty loop_start_sha
    local files_changed=$(detect_progress_with_commits "" "$current_sha")

    # Should fall back to uncommitted changes (1 file)
    [ "$files_changed" -eq 1 ]
}

# =============================================================================
# QUESTION DETECTION IN ANALYZE_RESPONSE (Issue #190 Bug 2)
# =============================================================================

@test "analyze_response sets asking_questions=true for question text output" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Should I implement approach A or B? Which option do you prefer?" > "$output_file"

    run analyze_response "$output_file" 1

    assert_success

    local asking=$(jq -r '.analysis.asking_questions' "$RALPH_DIR/.response_analysis")
    assert_equal "$asking" "true"
}

@test "analyze_response sets asking_questions=false for normal output" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Implementing feature X. All tests passed successfully." > "$output_file"

    run analyze_response "$output_file" 1

    assert_success

    local asking=$(jq -r '.analysis.asking_questions' "$RALPH_DIR/.response_analysis")
    assert_equal "$asking" "false"
}

@test "analyze_response does not crash when .last_output_length is zero (regression PR #333: division by zero)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    # Simulate a prior loop that wrote a zero output length
    # (e.g. an interrupted/crashed agent call that produced no output)
    echo "0" > "$RALPH_DIR/.last_output_length"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Implementing feature X. Continuing work on the next steps." > "$output_file"

    run analyze_response "$output_file" 1

    # Before the fix this aborted with "division by 0" mid-execution
    assert_success
    [ -f "$RALPH_DIR/.response_analysis" ]
}

@test "analyze_response does not crash when .last_output_length is empty (regression PR #333)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    # Empty file — fails the ^[0-9]+$ guard; last_length must default without dividing by zero
    printf '' > "$RALPH_DIR/.last_output_length"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Implementing feature X. Continuing work on the next steps." > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    [ -f "$RALPH_DIR/.response_analysis" ]
}

@test "analyze_response does not crash when .last_output_length is non-numeric (regression PR #333)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    # Real non-numeric content — exercises the ^[0-9]+$ guard's false branch with a
    # non-empty value (distinct from the empty-file case above)
    printf 'not-a-number\n' > "$RALPH_DIR/.last_output_length"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Implementing feature X. Continuing work on the next steps." > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    [ -f "$RALPH_DIR/.response_analysis" ]
}

@test "analyze_response output-decline heuristic still adds +10 when last length is a valid positive integer (PR #333 criterion 2)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    git init --quiet
    git config user.email "test@test.com"
    git config user.name "Test"
    echo "init" > init.txt
    git add init.txt
    git commit --quiet -m "init"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Implementing feature X. Continuing work on the next steps." > "$output_file"

    # Run A: previous output much larger -> ratio < 50% -> +10 confidence
    echo "1000" > "$RALPH_DIR/.last_output_length"
    run analyze_response "$output_file" 1
    assert_success
    local score_decline
    score_decline=$(jq -r '.analysis.confidence_score' "$RALPH_DIR/.response_analysis")

    # Run B: identical output/state, previous length tiny -> ratio >= 50% -> no bonus
    echo "1" > "$RALPH_DIR/.last_output_length"
    run analyze_response "$output_file" 2
    assert_success
    local score_no_decline
    score_no_decline=$(jq -r '.analysis.confidence_score' "$RALPH_DIR/.response_analysis")

    # Only the decline bonus differs between the two runs
    assert_equal "$((score_decline - score_no_decline))" "10"
}

# =============================================================================
# PROGRESS DETECTION IN NON-GIT WORKSPACES (Issue #340)
# =============================================================================
# When the loop CWD is not a git repository (multi-repo workspace root),
# git-based progress detection is skipped entirely. These tests cover the two
# fallback signal paths: (1) the $RALPH_DIR tracker repository, and (2) an
# explicit agent self-report in the RALPH_STATUS block.

@test "analyze_response detects progress from RALPH_DIR repo when CWD is not a git repo (issue #340)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # CWD (TEST_TEMP_DIR) is intentionally NOT a git repository.
    # The tracker directory is its own repository with a tracked fix_plan.md.
    git -C "$RALPH_DIR" init --quiet
    git -C "$RALPH_DIR" config user.email "test@test.com"
    git -C "$RALPH_DIR" config user.name "Test"
    echo "- [ ] item one" > "$RALPH_DIR/fix_plan.md"
    git -C "$RALPH_DIR" add fix_plan.md
    git -C "$RALPH_DIR" commit --quiet -m "baseline"

    # Simulate loop work: the tracker file is updated during the loop
    echo "- [x] item one" > "$RALPH_DIR/fix_plan.md"

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Consolidated the PR review and updated the tracker." > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    local progress=$(jq -r '.analysis.has_progress' "$RALPH_DIR/.response_analysis")
    local files=$(jq -r '.analysis.files_modified' "$RALPH_DIR/.response_analysis")
    assert_equal "$progress" "true"
    assert_equal "$files" "1"
}

@test "analyze_response does not crash when neither CWD nor RALPH_DIR is a git repo (issue #340)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # No git repository anywhere: CWD is plain, RALPH_DIR is plain
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.log"
    echo "Worked on documentation." > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    [ -f "$RALPH_DIR/.response_analysis" ]
    local progress=$(jq -r '.analysis.has_progress' "$RALPH_DIR/.response_analysis")
    assert_equal "$progress" "false"
}

@test "analyze_response trusts FILES_MODIFIED self-report in RALPH_STATUS block (issue #340)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Non-git CWD, no tracker repo: only the agent self-report is available
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.json"
    jq -n '{
        result: "Committed fixes in a sub-repository via git -C.\n---RALPH_STATUS---\nSTATUS: IN_PROGRESS\nEXIT_SIGNAL: false\nFILES_MODIFIED: 3\n---END_RALPH_STATUS---",
        sessionId: "test-session"
    }' > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    local progress=$(jq -r '.analysis.has_progress' "$RALPH_DIR/.response_analysis")
    local files=$(jq -r '.analysis.files_modified' "$RALPH_DIR/.response_analysis")
    assert_equal "$progress" "true"
    assert_equal "$files" "3"
}

@test "analyze_response trusts PROGRESS: true self-report without FILES_MODIFIED (issue #340)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    # Work with no local file changes at all (e.g. posting a PR review):
    # the agent reports progress explicitly
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.json"
    jq -n '{
        result: "Posted the consolidated review summary on the open PR.\n---RALPH_STATUS---\nSTATUS: IN_PROGRESS\nEXIT_SIGNAL: false\nPROGRESS: true\n---END_RALPH_STATUS---",
        sessionId: "test-session"
    }' > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    local progress=$(jq -r '.analysis.has_progress' "$RALPH_DIR/.response_analysis")
    local files=$(jq -r '.analysis.files_modified' "$RALPH_DIR/.response_analysis")
    assert_equal "$progress" "true"
    assert_equal "$files" "0"
}

@test "analyze_response keeps has_progress false on explicit FILES_MODIFIED: 0 (issue #340)" {
    # Skip if git is not available (analyze_response uses git)
    if ! command -v git &>/dev/null; then
        skip "git not available"
    fi

    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    mkdir -p "$RALPH_DIR/logs"

    local output_file="$RALPH_DIR/logs/claude_output_test.json"
    jq -n '{
        result: "Re-scanned open PRs; nothing actionable this loop.\n---RALPH_STATUS---\nSTATUS: IN_PROGRESS\nEXIT_SIGNAL: false\nFILES_MODIFIED: 0\n---END_RALPH_STATUS---",
        sessionId: "test-session"
    }' > "$output_file"

    run analyze_response "$output_file" 1

    assert_success
    local progress=$(jq -r '.analysis.has_progress' "$RALPH_DIR/.response_analysis")
    assert_equal "$progress" "false"
}

# --- Stale Exit Signals Tests (Issue #194) ---

@test "startup resets stale exit signals before main loop" {
    # Verify ralph_loop.sh resets EXIT_SIGNALS_FILE before the while-true loop
    # This is the primary fix for #194: stale signals from a prior run
    # must not cause immediate exit on next invocation
    local script="${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Find the "Starting main loop" log message (just before while true)
    local main_loop_line
    main_loop_line=$(grep -n 'Starting main loop' "$script" | head -1 | cut -d: -f1)
    [[ -n "$main_loop_line" ]]

    # Find the exit signals reset that should appear BEFORE the main loop
    local reset_line
    reset_line=$(grep -n 'Reset exit signals\|reset.*exit.*signal' "$script" | awk -F: -v limit="$main_loop_line" '$1 < limit {print $1}' | tail -1)
    [[ -n "$reset_line" ]]

    # The reset block must reference EXIT_SIGNALS_FILE
    local reset_context
    reset_context=$(sed -n "$((reset_line-3)),$((reset_line+3))p" "$script")
    echo "$reset_context" | grep -q 'EXIT_SIGNALS_FILE'
}

@test "stale exit signals do not cause premature exit" {
    # Simulate: previous run left stale completion_indicators in .exit_signals
    # A fresh should_exit_gracefully() call after reset should NOT exit
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1, 2, 3, 4, 5]}' > "$EXIT_SIGNALS_FILE"

    # Create stale .response_analysis with exit_signal=true
    cat > "$RESPONSE_ANALYSIS_FILE" << 'EOF'
{"loop_number": 5, "analysis": {"exit_signal": true, "confidence_score": 90}}
EOF

    # Before reset: should_exit_gracefully would trigger safety_circuit_breaker
    run should_exit_gracefully
    [[ "$output" != "" ]]  # Would exit

    # Simulate startup reset (what main() now does before the loop)
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"
    rm -f "$RESPONSE_ANALYSIS_FILE"

    # After reset: should_exit_gracefully should NOT trigger
    run should_exit_gracefully
    [[ "$output" == "" ]]
}

@test "should_exit_gracefully logs diagnostic signal counts" {
    # Verify that should_exit_gracefully() logs signal counts for diagnosability
    local script="${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Extract the function body
    local func_body
    func_body=$(sed -n '/^should_exit_gracefully()/,/^}/p' "$script")

    # Should contain diagnostic logging of signal counts
    echo "$func_body" | grep -q 'recent_test_loops\|recent_done_signals\|recent_completion_indicators'
    # Should have a log_status call that includes signal counts for debugging
    echo "$func_body" | grep -q 'log_status.*signal\|log_status.*exit.*check\|log_status.*DEBUG.*indicator'
}

@test "API limit user-exit path calls reset_session" {
    # The "user chose to exit" path for API limits must call reset_session
    # to prevent stale .exit_signals from causing premature exit on next run
    local script="${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Find the API limit user exit block
    local exit_block
    exit_block=$(sed -n '/user_choice.*==.*"2"/,/break/p' "$script")

    # Must call reset_session before break
    echo "$exit_block" | grep -q 'reset_session'
}
