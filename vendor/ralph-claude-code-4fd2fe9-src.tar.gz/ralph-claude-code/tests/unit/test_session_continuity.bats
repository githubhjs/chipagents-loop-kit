#!/usr/bin/env bats
# Unit tests for session continuity enhancements
# TDD: Tests for session lifecycle management across Ralph loops

load '../helpers/test_helper'
load '../helpers/fixtures'

setup() {
    # Create temporary test directory
    TEST_DIR="$(mktemp -d)"
    cd "$TEST_DIR"

    # Initialize git repo
    git init > /dev/null 2>&1
    git config user.email "test@example.com"
    git config user.name "Test User"

    # Set up environment with .ralph/ subfolder structure
    export RALPH_DIR=".ralph"
    export PROMPT_FILE="$RALPH_DIR/PROMPT.md"
    export LOG_DIR="$RALPH_DIR/logs"
    export DOCS_DIR="$RALPH_DIR/docs/generated"
    export STATUS_FILE="$RALPH_DIR/status.json"
    export EXIT_SIGNALS_FILE="$RALPH_DIR/.exit_signals"
    export CALL_COUNT_FILE="$RALPH_DIR/.call_count"
    export TIMESTAMP_FILE="$RALPH_DIR/.last_reset"
    export CLAUDE_SESSION_FILE="$RALPH_DIR/.claude_session_id"
    export RALPH_SESSION_FILE="$RALPH_DIR/.ralph_session"
    export RALPH_SESSION_HISTORY_FILE="$RALPH_DIR/.ralph_session_history"
    export RESPONSE_ANALYSIS_FILE="$RALPH_DIR/.response_analysis"
    export CLAUDE_MIN_VERSION="2.0.76"
    export CLAUDE_CODE_CMD="claude"
    export CLAUDE_USE_CONTINUE="true"

    mkdir -p "$LOG_DIR" "$DOCS_DIR"
    echo "0" > "$CALL_COUNT_FILE"
    echo "$(date +%Y%m%d%H)" > "$TIMESTAMP_FILE"
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": []}' > "$EXIT_SIGNALS_FILE"

    # Create sample project files in .ralph/ directory
    create_sample_prompt "$RALPH_DIR/PROMPT.md"
    create_sample_fix_plan "$RALPH_DIR/fix_plan.md" 10 3

    # Source library components
    source "${BATS_TEST_DIRNAME}/../../lib/date_utils.sh"
    source "${BATS_TEST_DIRNAME}/../../lib/response_analyzer.sh"
    source "${BATS_TEST_DIRNAME}/../../lib/circuit_breaker.sh"

    # Exercise the real reset implementation, including its history dependency.
    local function_name function_body
    for function_name in reset_session log_session_transition; do
        function_body=$(sed -n "/^${function_name}() {/,/^}/p" "${BATS_TEST_DIRNAME}/../../ralph_loop.sh")
        [[ -n "$function_body" ]] || return 1
        eval "$function_body"
        declare -F "$function_name" > /dev/null || return 1
    done

    # Define color variables for log_status
    RED='\033[0;31m'
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    BLUE='\033[0;34m'
    PURPLE='\033[0;35m'
    NC='\033[0m'

    # Define log_status function for tests
    log_status() {
        local level=$1
        local message=$2
        echo "[$level] $message"
    }
    export -f log_status
}

teardown() {
    if [[ -n "$TEST_DIR" ]] && [[ -d "$TEST_DIR" ]]; then
        cd /
        rm -rf "$TEST_DIR"
    fi
}

# =============================================================================
# HELPER: Check if function exists in ralph_loop.sh
# =============================================================================

function_exists_in_ralph() {
    local func_name=$1
    grep -qE "^${func_name}\s*\(\)|^function\s+${func_name}" "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" 2>/dev/null
}

# =============================================================================
# --reset-session CLI FLAG TESTS
# =============================================================================

@test "--reset-session resets session file" {
    # Create a session file
    echo '{"session_id": "session-to-reset", "timestamp": "2026-01-09T10:00:00Z"}' > "$RALPH_SESSION_FILE"
    echo 'session-to-reset' > "$CLAUDE_SESSION_FILE"

    # Run with --reset-session flag (should exit quickly)
    run timeout 5 bash "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" --reset-session 2>&1

    # If flag not recognized, skip
    if [[ "$output" == *"Unknown option"* ]]; then
        skip "--reset-session flag not yet implemented"
    fi

    # Check that session was reset
    if [[ -f "$RALPH_SESSION_FILE" ]]; then
        local session=$(jq -r '.session_id // ""' "$RALPH_SESSION_FILE" 2>/dev/null || echo "")
        [[ -z "$session" || "$session" == "" || "$session" == "null" ]]
    fi
}

# =============================================================================
# CIRCUIT BREAKER SESSION INTEGRATION TESTS
# =============================================================================

@test "cleanup function includes session reset" {
    # Check if cleanup function includes reset_session
    run grep -A5 'cleanup()' "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    [[ "$output" == *"reset_session"* ]] || skip "Cleanup session reset not yet implemented"
}

# =============================================================================
# RESPONSE ANALYZER SESSION FUNCTIONS (already implemented)
# =============================================================================

@test "store_session_id writes session to file with timestamp" {
    run store_session_id "session-test-abc"

    [[ -f "$CLAUDE_SESSION_FILE" ]] || skip "store_session_id not yet implemented"

    local content=$(cat "$CLAUDE_SESSION_FILE")
    [[ "$content" == *"session-test-abc"* ]]
}

@test "get_last_session_id retrieves stored session" {
    # First store a session
    echo '{"session_id": "session-retrieve-test", "timestamp": "2026-01-09T10:00:00Z"}' > "$CLAUDE_SESSION_FILE"

    run get_last_session_id

    [[ "$output" == *"session-retrieve-test"* ]]
}

@test "get_last_session_id returns empty when no session file" {
    rm -f "$CLAUDE_SESSION_FILE"

    run get_last_session_id

    # Should return empty string, not error
    [[ $status -eq 0 ]]
    [[ -z "$output" || "$output" == "" || "$output" == "null" ]]
}

@test "should_resume_session returns true for recent session" {
    # Store a recent session
    local now_iso=$(date -Iseconds 2>/dev/null || date +%Y-%m-%dT%H:%M:%S%z)
    echo "{\"session_id\": \"session-recent\", \"timestamp\": \"$now_iso\"}" > "$CLAUDE_SESSION_FILE"

    run should_resume_session

    # Should indicate session can be resumed
    [[ "$output" == "true" ]]
}

@test "should_resume_session returns false for old session" {
    # Store an old session (24+ hours ago)
    echo '{"session_id": "session-old", "timestamp": "2020-01-01T00:00:00Z"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session

    # Should indicate session expired
    [[ "$output" == "false" ]]
}

@test "should_resume_session honors a non-UTC offset (issue #368)" {
    # 2h old in UTC terms, written with a -07:00 offset: must resume (< 24h)
    local ts
    ts=$(TZ=America/Los_Angeles date -d "@$(( $(date +%s) - 7200 ))" +%Y-%m-%dT%H:%M:%S%:z 2>/dev/null) || skip "date -d @epoch unavailable"
    echo "{\"session_id\": \"s-offset\", \"timestamp\": \"$ts\"}" > "$CLAUDE_SESSION_FILE"

    run should_resume_session
    [[ "$output" == "true" ]]
}

@test "should_resume_session works when date does not identify as GNU (issue #368)" {
    # uutils coreutils supports `date -d` but its --version has no "GNU"
    date() { if [[ "${1:-}" == "--version" ]]; then echo "date (uutils coreutils) 0.10.0"; else command date "$@"; fi; }
    local now_iso
    now_iso=$(get_iso_timestamp)
    echo "{\"session_id\": \"s-uutils\", \"timestamp\": \"$now_iso\"}" > "$CLAUDE_SESSION_FILE"

    run should_resume_session
    [[ "$output" == "true" ]]
}

@test "should_resume_session returns false for an unparsable timestamp (issue #368)" {
    echo '{"session_id": "s-bad", "timestamp": "not-a-date"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session
    [[ "$output" == "false" ]]
}

@test "should_resume_session returns false for a well-formed but impossible timestamp (issue #368)" {
    echo '{"session_id": "s-bad", "timestamp": "2026-13-45T99:99:99+00:00"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session
    [[ "$output" == "false" ]]
}

@test "should_resume_session rejects impossible timestamps where date normalizes them (BSD/macOS, issue #368)" {
    # BSD `date -j -f` does no range checking: 2026-13-45T99:99:99 silently
    # rolls over into a valid epoch. Simulate that date on any host.
    date() {
        case "$*" in
            *-d*) return 1 ;;                                  # BSD: no GNU -d
            *-j*) command date +%s ;;                          # "normalized" -> now
            *) command date "$@" ;;
        esac
    }
    echo '{"session_id": "s-bsd", "timestamp": "2026-13-45T99:99:99+00:00"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session
    [[ "$output" == "false" ]]
}

@test "should_resume_session returns false when no session file" {
    rm -f "$CLAUDE_SESSION_FILE"

    run should_resume_session

    # Should indicate no session to resume
    [[ "$output" == "false" ]]
}

# =============================================================================
# SESSION ID EXTRACTION FROM CLAUDE OUTPUT
# =============================================================================

@test "parse_json_response extracts sessionId from Claude CLI format" {
    local output_file="$LOG_DIR/test_output.log"

    cat > "$output_file" << 'EOF'
{
    "result": "Working on feature implementation.",
    "sessionId": "session-unique-123"
}
EOF

    run parse_json_response "$output_file"
    local result_file="$RALPH_DIR/.json_parse_result"

    [[ -f "$result_file" ]]

    local session_id=$(jq -r '.session_id' "$result_file")
    assert_equal "$session_id" "session-unique-123"
}

@test "analyze_response persists sessionId to session file" {
    local output_file="$LOG_DIR/test_output.log"

    cat > "$output_file" << 'EOF'
{
    "result": "Working on implementation.",
    "sessionId": "session-persist-test-456"
}
EOF

    analyze_response "$output_file" 1

    # Session ID should be persisted
    [[ -f "$CLAUDE_SESSION_FILE" ]]

    local stored=$(cat "$CLAUDE_SESSION_FILE" 2>/dev/null)
    [[ "$stored" == *"session-persist-test-456"* ]]
}

# =============================================================================
# SESSION EXPIRATION HANDLING
# =============================================================================

@test "expired session (24+ hours) is not resumed" {
    # Create old session
    echo '{"session_id": "old-session", "timestamp": "2020-01-01T00:00:00Z"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session

    [[ "$output" == "false" ]]
}

@test "CLAUDE_SESSION_EXPIRY_HOURS defaults to 24" {
    # Source ralph_loop.sh in a subshell to get the default
    run bash -c "source '${BATS_TEST_DIRNAME}/../../ralph_loop.sh'; echo \$CLAUDE_SESSION_EXPIRY_HOURS"

    # Should contain 24 as default
    [[ "$output" == *"24"* ]] || skip "CLAUDE_SESSION_EXPIRY_HOURS not yet implemented"
}

@test "--session-expiry flag is recognized in help" {
    run bash "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" --help

    [[ "$output" == *"session-expiry"* ]] || skip "--session-expiry flag not yet implemented"
}

@test "--session-expiry rejects non-integer value" {
    run timeout 5 bash "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" --session-expiry abc 2>&1

    # Should fail with error about invalid value
    if [[ "$output" == *"Unknown option"* ]]; then
        skip "--session-expiry flag not yet implemented"
    fi

    [[ "$output" == *"positive integer"* ]] || [[ "$output" == *"Error"* ]]
}

@test "--session-expiry rejects zero value" {
    run timeout 5 bash "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" --session-expiry 0 2>&1

    # Should fail with error about invalid value
    if [[ "$output" == *"Unknown option"* ]]; then
        skip "--session-expiry flag not yet implemented"
    fi

    [[ "$output" == *"positive integer"* ]] || [[ "$output" == *"Error"* ]]
}

@test "--session-expiry rejects negative value" {
    run timeout 5 bash "${BATS_TEST_DIRNAME}/../../ralph_loop.sh" --session-expiry -5 2>&1

    # Should fail with error about invalid value
    if [[ "$output" == *"Unknown option"* ]]; then
        skip "--session-expiry flag not yet implemented"
    fi

    [[ "$output" == *"positive integer"* ]] || [[ "$output" == *"Error"* ]]
}

@test "get_session_file_age_hours returns 0 for missing file" {
    # Source the script to get the function
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Test with non-existent file
    run get_session_file_age_hours "/nonexistent/path/file"

    [[ "$output" == "0" ]]
}

@test "get_session_file_age_hours returns -1 for stat failure" {
    # Source the script to get the function
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Create a file then make it inaccessible (simulate stat failure via directory permissions)
    local test_file="$TEST_DIR/unreadable_file"
    echo "test" > "$test_file"

    # Verify the function code handles stat failure by checking the implementation
    run grep -A35 'get_session_file_age_hours' "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"
    [[ "$output" == *'echo "-1"'* ]]
}

@test "init_claude_session removes expired session file" {
    # Source the script to get the function
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"

    # Create an old session file (simulate by setting low expiry)
    echo '{"session_id": "old-session", "timestamp": 1000000000}' > "$CLAUDE_SESSION_FILE"
    touch -d "2020-01-01" "$CLAUDE_SESSION_FILE" 2>/dev/null || touch -t 202001010000 "$CLAUDE_SESSION_FILE"

    # Set very short expiry to trigger expiration
    CLAUDE_SESSION_EXPIRY_HOURS=1

    run init_claude_session

    # Session file should be removed
    [[ ! -f "$CLAUDE_SESSION_FILE" ]] || [[ "$output" == *"expired"* ]]
}

# =============================================================================
# EDGE CASES
# =============================================================================

@test "store_session_id handles empty session ID" {
    run store_session_id ""

    # Should fail or return error status
    [[ $status -ne 0 ]]
}

@test "get_last_session_id handles corrupted JSON file" {
    echo "not valid json at all {{{" > "$CLAUDE_SESSION_FILE"

    run get_last_session_id

    # Should not error, should return empty
    [[ $status -eq 0 ]]
    [[ -z "$output" || "$output" == "" || "$output" == "null" ]]
}

@test "should_resume_session handles corrupted JSON file" {
    echo "corrupted json {{{" > "$CLAUDE_SESSION_FILE"

    run should_resume_session

    # Should return false, not error
    [[ $status -eq 0 || $status -eq 1 ]]  # Either is acceptable
    [[ "$output" == "false" ]]
}

@test "should_resume_session handles missing timestamp field" {
    echo '{"session_id": "session-no-time"}' > "$CLAUDE_SESSION_FILE"

    run should_resume_session

    # Should return false since no timestamp to validate
    [[ "$output" == "false" ]]
}

# =============================================================================
# INTEGRATION: FULL SESSION LIFECYCLE
# =============================================================================

@test "full session lifecycle: store -> get -> check -> expires" {
    # 1. Store a session
    store_session_id "lifecycle-session-001"

    # 2. Get it back
    local stored=$(get_last_session_id)
    [[ "$stored" == "lifecycle-session-001" ]]

    # 3. Check if resumable (should be true since just created)
    run should_resume_session
    [[ "$output" == "true" ]]

    # 4. Simulate expiration by setting old timestamp
    echo '{"session_id": "lifecycle-session-001", "timestamp": "2020-01-01T00:00:00Z"}' > "$CLAUDE_SESSION_FILE"

    # 5. Check again (should be expired)
    run should_resume_session
    [[ "$output" == "false" ]]
}

# =============================================================================
# Issue #123: UNIFIED SESSION STORAGE FORMAT (JSON, tolerant readers)
# =============================================================================

@test "issue #123: write_session_id_file writes canonical JSON with timestamp" {
    write_session_id_file "sess-123-abc" "$CLAUDE_SESSION_FILE"

    # Valid JSON, with session_id and a non-empty timestamp
    run jq -e . "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ "$(jq -r '.session_id' "$CLAUDE_SESSION_FILE")" == "sess-123-abc" ]]
    # // empty so a missing field is "" (jq -r prints "null" otherwise, passing falsely)
    [[ -n "$(jq -r '.timestamp // empty' "$CLAUDE_SESSION_FILE")" ]]
}

@test "issue #123: write_session_id_file rejects empty id" {
    rm -f "$CLAUDE_SESSION_FILE"
    run write_session_id_file "" "$CLAUDE_SESSION_FILE"
    [ "$status" -ne 0 ]
    [[ ! -f "$CLAUDE_SESSION_FILE" ]]
}

@test "issue #123: write_session_id_file reports failure (rc 1) when it cannot write" {
    [[ "$(id -u)" -eq 0 ]] && skip "root bypasses directory permissions"
    local rodir="$TEST_DIR/readonly"
    mkdir -p "$rodir"; chmod 555 "$rodir"

    run write_session_id_file "no-write-id" "$rodir/sess"
    chmod 755 "$rodir"   # restore so teardown can clean up

    [ "$status" -ne 0 ]
    [[ ! -f "$rodir/sess" ]]
    # No orphaned temp files left behind
    [[ -z "$(ls -A "$rodir" 2>/dev/null)" ]]
}

@test "issue #123: read_session_id_file reads JSON format" {
    echo '{"session_id": "json-id-1", "timestamp": "2026-01-09T10:00:00Z"}' > "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ "$output" == "json-id-1" ]]
}

@test "issue #123: read_session_id_file reads legacy plain-text format" {
    printf 'plain-legacy-id-2\n' > "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ "$output" == "plain-legacy-id-2" ]]
}

@test "issue #123: read_session_id_file strips CR from legacy plain id (issue #254 robustness)" {
    printf 'abc123-session-id\r\n' > "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [[ "$output" == "abc123-session-id" ]]
}

@test "issue #123: read_session_id_file returns empty on corrupt/JSON-looking junk" {
    echo 'not valid json at all {{{' > "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ -z "$output" ]]
}

@test "issue #123: read_session_id_file rejects a legacy line with interior whitespace" {
    # "abc 123" must NOT be normalized into a valid "abc123" id (CodeRabbit)
    printf 'abc 123\n' > "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ -z "$output" ]]
}

@test "issue #123: read_session_id_file returns empty for missing file" {
    rm -f "$CLAUDE_SESSION_FILE"
    run read_session_id_file "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]
    [[ -z "$output" ]]
}

@test "issue #123: save_claude_session persists canonical JSON (not plain text)" {
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"
    local output_file="$LOG_DIR/claude_out.json"
    echo '{"session_id": "save-json-id", "result": "ok"}' > "$output_file"

    save_claude_session "$output_file"

    [[ -f "$CLAUDE_SESSION_FILE" ]]
    run jq -e . "$CLAUDE_SESSION_FILE"
    [ "$status" -eq 0 ]                                   # file is valid JSON
    [[ "$(jq -r '.session_id' "$CLAUDE_SESSION_FILE")" == "save-json-id" ]]
}

@test "issue #123: init_claude_session resumes from a JSON session file" {
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"
    # Recent JSON file (mtime = now -> not expired)
    write_session_id_file "resume-json-id" "$CLAUDE_SESSION_FILE"

    run init_claude_session
    # Must return the real id, NOT "{" (the old plain-text reader's failure mode)
    [[ "$output" == *"resume-json-id"* ]]
    [[ "$output" != *"{"* ]]
}

@test "issue #123: init_claude_session resumes from a legacy plain-text file" {
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"
    printf 'legacy-plain-resume\n' > "$CLAUDE_SESSION_FILE"

    run init_claude_session
    [[ "$output" == *"legacy-plain-resume"* ]]
}

@test "issue #123: save_claude_session -> init_claude_session round-trips the id" {
    source "${BATS_TEST_DIRNAME}/../../ralph_loop.sh"
    local output_file="$LOG_DIR/claude_out.json"
    echo '{"session_id": "roundtrip-xyz"}' > "$output_file"

    save_claude_session "$output_file"
    run init_claude_session
    [[ "$output" == *"roundtrip-xyz"* ]]
    [[ "$output" != *"{"* ]]
}

@test "issue #123: get_last_session_id reads a legacy plain-text id" {
    printf 'legacy-getlast-id\n' > "$CLAUDE_SESSION_FILE"
    run get_last_session_id
    [[ "$output" == "legacy-getlast-id" ]]
}

# =============================================================================
# SESSION RESET CLEARS EXIT SIGNALS (Issue #91 Fix)
# =============================================================================

@test "reset_session clears exit_signals file to prevent premature exit" {
    # Setup: Create stale exit signals that would cause premature exit
    echo '{"test_only_loops": [1,2], "done_signals": [1], "completion_indicators": [1,2,3]}' > "$EXIT_SIGNALS_FILE"

    # Verify stale signals exist
    local completion_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    [[ "$completion_count" == "3" ]]

    export RALPH_SESSION_HISTORY_FILE="$RALPH_DIR/.ralph_session_history"
    export RESPONSE_ANALYSIS_FILE="$RALPH_DIR/.response_analysis"

    # Create a mock response analysis file
    echo '{"analysis": {"exit_signal": true}}' > "$RESPONSE_ANALYSIS_FILE"
    [[ -f "$RESPONSE_ANALYSIS_FILE" ]]

    # Call reset_session
    reset_session "test_reset"

    # Verify exit signals were cleared
    local new_completion_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    [[ "$new_completion_count" == "0" ]]

    local new_test_loops=$(jq '.test_only_loops | length' "$EXIT_SIGNALS_FILE")
    [[ "$new_test_loops" == "0" ]]

    local new_done_signals=$(jq '.done_signals | length' "$EXIT_SIGNALS_FILE")
    [[ "$new_done_signals" == "0" ]]

    # Verify response analysis was cleared
    [[ ! -f "$RESPONSE_ANALYSIS_FILE" ]]
}

@test "reset_session prevents issue #91 scenario (stale completion indicators)" {
    # Issue #91: Ralph exits immediately when stale completion_indicators exist

    # Ensure variables are set before use (defensive against env differences)
    export RESPONSE_ANALYSIS_FILE="$RALPH_DIR/.response_analysis"
    export RALPH_SESSION_HISTORY_FILE="$RALPH_DIR/.ralph_session_history"

    # Simulate the issue scenario:
    # 1. Previous session ended with completion_indicators: [1,2]
    # 2. Previous session had EXIT_SIGNAL: true
    echo '{"test_only_loops": [], "done_signals": [], "completion_indicators": [1,2]}' > "$EXIT_SIGNALS_FILE"
    echo '{"analysis": {"exit_signal": true, "has_completion_signal": true}}' > "$RESPONSE_ANALYSIS_FILE"

    # Verify the problematic state exists
    local completion_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    [[ "$completion_count" == "2" ]]

    local exit_signal=$(jq -r '.analysis.exit_signal' "$RESPONSE_ANALYSIS_FILE")
    [[ "$exit_signal" == "true" ]]

    # User runs --reset-session
    reset_session "manual_reset"

    # Verify the fix: completion indicators should be cleared
    local new_completion_count=$(jq '.completion_indicators | length' "$EXIT_SIGNALS_FILE")
    [[ "$new_completion_count" == "0" ]]

    # Verify response analysis is gone (no stale EXIT_SIGNAL)
    [[ ! -f "$RESPONSE_ANALYSIS_FILE" ]]
}
